/*
 * main_producer_consumer.c
 *
 *  Created on: 23/10/2012
 *      Author: utnso
 */

#include <stdio.h>
#include <pthread.h>
#include "producer_consumer.h"
#include "list.h"


#define MAX_COUNT 2000

void *producerThread(producer_consumer_t *pc){

	for(int32_t counter = 0; counter < 1000 ; counter++){
		int32_t *element = malloc(sizeof(int32_t));
		*element = counter;
		producer(pc, (void (*)(void *, void *))list_add, element);
	}
	pthread_exit(NULL);
}

void *consumerThread(producer_consumer_t *pc){
	//Hago esto, para que no quede eternamente bloqueado

	int32_t count_element = 0; //Lo se de antemano

	while(count_element < MAX_COUNT){
			int32_t *element = consumer(pc, (void *(*)(void *, void *))list_remove, 0);
			printf(" %d ", *element);
			free(element);
			count_element++;
	}
	pthread_exit(NULL);
}


int main(int argc, char **argv) {
	pthread_t th[3];
	t_list *list = list_create();
	producer_consumer_t *pc = producer_cosumer_init(list, 100, (int32_t (*)(void *))list_size);

	pthread_create(&th[0], NULL, (void *(*)(void *))producerThread, pc);
	pthread_create(&th[1], NULL, (void *(*)(void *))producerThread, pc);
	pthread_create(&th[2], NULL, (void *(*)(void *))consumerThread, pc);

	for(int32_t thread=0; thread < 3; thread++) pthread_join(th[thread], NULL);

	printf("\n\nCantidad de elementos que quedaron: %d\n", list_size(list) );
	list_destroy(list);
	producer_cosumer_destroy(pc);
}
