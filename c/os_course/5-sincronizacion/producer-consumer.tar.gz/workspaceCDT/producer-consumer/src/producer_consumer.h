/*
 * producer_consumer.h
 *
 *  Created on: 23/10/2012
 *      Author: utnso
 *
 * IDEA: Trabaja con objetos de colecciones (collections de commons-library)
 */

#ifndef PRODUCER_CONSUMER_H_
#define PRODUCER_CONSUMER_H_

#include <stdlib.h>
#include <pthread.h>
#include <inttypes.h>

	typedef struct{
		pthread_cond_t sem_a;
		pthread_cond_t sem_b;
		pthread_mutex_t mutex;
		void *collection;
		int32_t (*function_size)(void *collection);
		int32_t max_size_collections;
	}producer_consumer_t;

producer_consumer_t * producer_cosumer_init(void *collection_instance, int32_t max_size_collection, int32_t (*function_size)(void *));

int32_t function_collection_size(producer_consumer_t *producer_consumer);

void*	consumer(producer_consumer_t *producer_consumer, void *(*consumer_function)(void* c, void* param),  void *consumer_function_param );

int32_t	producer(producer_consumer_t *producer_consumer, void (*producer_function)(void* c, void* param),  void *producer_function_param );

void producer_cosumer_destroy(producer_consumer_t *producer_consumer);


#endif /* PRODUCER_CONSUMER_H_ */
