/*
 * producer_consumer.c
 *
 *  Created on: 23/10/2012
 *      Author: utnso
 */
#include "producer_consumer.h"

producer_consumer_t * producer_cosumer_init(void *collection_instance, int32_t max_size_collection, int32_t (*function_size)(void *)){
	producer_consumer_t *object = malloc( sizeof(producer_consumer_t) );
	pthread_mutex_init(&object->mutex , NULL);
	pthread_cond_init(&object->sem_a, NULL);
	pthread_cond_init(&object->sem_b, NULL);
	object->collection=collection_instance;
	object->function_size = function_size;
	object->max_size_collections = max_size_collection;
	return object;
}

int32_t producer(producer_consumer_t *producer_consumer, void (*producer_function)(void* c, void* param),  void *producer_function_param ){

	pthread_mutex_lock(&producer_consumer->mutex);

	//Mientras que el buffer esta lleno, se bloquea
	while( function_collection_size(producer_consumer) > producer_consumer->max_size_collections  )
		pthread_cond_wait(&producer_consumer->sem_a, &producer_consumer->mutex);

	//PRODUCIR
	producer_function(producer_consumer->collection, producer_function_param);

	//Si no esta vacio la coleccion
	if( function_collection_size(producer_consumer) > 0 )
		pthread_cond_signal(&producer_consumer->sem_b);

	pthread_mutex_unlock(&producer_consumer->mutex);

	return EXIT_SUCCESS;
}

int32_t function_collection_size(producer_consumer_t *producer_consumer){
	return producer_consumer->function_size(producer_consumer->collection);
}

void *consumer(producer_consumer_t *producer_consumer, void *(*consumer_function)(void* c, void* param),  void *consumer_function_param ){
	void *data = NULL;
	pthread_mutex_lock(&producer_consumer->mutex);

	/*
	 * Mientras que el buffer esta vacio, se bloquea
	 * El tamaño lo maneja la propia colección en estos casos, la idea es que el consumidor,
	 * retire un objeto de la colección (remueva)
	 */
	while( function_collection_size(producer_consumer) == 0 )
		pthread_cond_wait(&producer_consumer->sem_b, &producer_consumer->mutex);

	//CONSUMIR
	data = consumer_function(producer_consumer->collection, consumer_function_param);

	//Si no esta lleno, habilita al productor
	if( function_collection_size(producer_consumer) < producer_consumer->max_size_collections)
		pthread_cond_signal(&producer_consumer->sem_a);

	//Libero el mutex luego de producir
	pthread_mutex_unlock(&producer_consumer->mutex);
	return data;
}

void producer_cosumer_destroy(producer_consumer_t *producer_consumer){
	pthread_mutex_destroy(&producer_consumer->mutex);
	pthread_cond_destroy(&producer_consumer->sem_a);
	pthread_cond_destroy(&producer_consumer->sem_b);
	free(producer_consumer);
}
